package ch.hearc.ProjetTE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetTeApplicationTests {

	@Test
	void contextLoads() {
	}

}
