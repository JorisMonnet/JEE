package ch.hearc.ProjetTE;

public enum ColorType {
	Inconnue, Blonde, Brune, Ambree, Blanche
}
