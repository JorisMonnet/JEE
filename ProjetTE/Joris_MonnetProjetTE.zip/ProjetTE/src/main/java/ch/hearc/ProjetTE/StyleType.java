package ch.hearc.ProjetTE;

public enum StyleType {
	Inconnue, Garde, Abbaye, Lager, Pale_Ale, India_Pale_Ale, Stout, Blanche, Saison, Sour, Fut
}
