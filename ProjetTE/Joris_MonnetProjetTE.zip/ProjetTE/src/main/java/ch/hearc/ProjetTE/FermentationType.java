package ch.hearc.ProjetTE;

public enum FermentationType {
	Inconnue, Basse, Haute, Spontanee, EnBouteille, Mixte
}
